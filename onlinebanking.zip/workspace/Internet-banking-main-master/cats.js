var mongoose=require("mongoose");
mongoose.connect("mongodb://localhost/cat_app")
//add a cat in the database
var catschema= new mongoose.Schema({
	name:String,
	age:Number,
	temperament:String
}); 
var Cat=mongoose.model("Cat",catschema);
var g=new Cat({
	name:"George",
	age:11,
	temperament:"Growling"
});
g.save(function(err,result){
	if(!err){
	console.log("inserted!!");
	console.log(result);
}
})