var express        =        require("express");
var bodyParser     =        require("body-parser");
var app            =        express();
var nodemailer = require('nodemailer');
//Here we are configuring express to use body-parser as middle-ware.
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(__dirname+''))
app.set('view engine','ejs');

//Data bases
var mongoose=require("mongoose");
mongoose.Promise = require('bluebird');
mongoose.connect("mongodb://localhost:27017/onlinebanking_app",{useNewUrlParser:true});

//accounts schema
var caschema= new mongoose.Schema({
	name:String,
	dob:Date,
    gender:String,
    Contact:String,
    Aadhar:String,
    Address:String,
    City:String, 
    state: String,
    Pincode:String,
    Savings: String,
    HomeLoan: String,
    Insurance: String,
    CreditCard: String,
    AccountNo: Number,
    email:String,
    currb:Number,
    homeb:Number,
    savb:Number,
    credb:Number
});
const account=mongoose.model("account",caschema);


var cschema= new mongoose.Schema({
    AccountNo:Number,
    UserName:String,
    Password:String,
    Security:String,
    Freeze:Number

});
const user=mongoose.model("user",cschema);



var alertschema= new mongoose.Schema({
    From:String,
    To:String,
    Subject:String,
    Body:String,
    Seen:Number
});
const alert=mongoose.model("alert",alertschema);
var llschema= new mongoose.Schema({
    One:String,
    Two:String,
    Category:String,
    Flag:String
});
const ll=mongoose.model("ll",llschema);


var aschema= new mongoose.Schema({
    accn:Number
});
const accnoo=mongoose.model("accnoo",aschema);

var payshema=new mongoose.Schema({
    acc1:Number,
    acc2:Number,
    pn:String
})
const payee=mongoose.model("payee",payshema);

var his=new mongoose.Schema({
    nam:String,
    accn1:Number,
    accn2:Number,
    amo:Number,
    stat:String,
    typ:String,
    date:String
})

const histran=mongoose.model("histran",his);


var wa=0;
//home page
app.get('/',function (req, res) {
   wa=0;
   res.sendFile(__dirname+'/index.html');})

//profile
app.get('/profile',function (req, res) {
   res.render('profile.ejs');})

//Login page
app.get('/Login',function (req, res) {
   res.sendFile(__dirname+'/login.html');})
   
   
    
//======================================================

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'katuri.vijaya02@gmail.com',
    pass: 'vijayacan99'
  }
});

//======================================================

//==============================================================================================Login Module
// //createacc
app.post('/createacc',function(req,res){
                    console.log(req.body);
                    accnoo.find({},function(err, result) {
                        console.log(result);
                        aa=result[0].accn;
                        accnoo.update({},{$set:{accn:aa+1}},{},function(){});
                        account.find({'Contact':req.body.tel},function(err, resul) {
                            if(resul.length==0){
                                account.find({'Aadhar':req.body.aadhaar},function(err, resu) {
                                    if(resu.length==0){
                                        var s=0,i=0,h=0,c=0;
                                        if(req.body.s!=undefined){s=1;}
                                        if(req.body.i!=undefined){i=1;}
                                        if(req.body.h!=undefined){h=1;}
                                        if(req.body.c!=undefined){c=1;}
                                        g=new account({
                                            AccountType: req.body.title,
                                            name: req.body.names,
                                            dob:req.body.date,
                                            gender: req.body.gender,
                                            Contact: req.body.tel,
                                            Aadhar :req.body.aadhaar,
                                            Address:req.body.address,
                                            City: req.body.city,
                                            state : req.body.state,
                                            Pincode: req.body.pin,
                                            AccountNo:aa,
                                            Savings:s,
                                            HomeLoan:h,
                                            Insurance:i,
                                            CreditCard:c,
                                            credb:Number(700),
                                            savb:Number(1000),
                                            currb:Number(10000),
                                            homeb:Number(5000),
                                            email:req.body.email
                                        });
                        
                                        console.log(g);
                                        g.save(function(err,result){
                                            if(!err){
                                                res.send("Congratulations!!!Your Account is Created!!\n Your Account Number is :   "+result.AccountNo+"\n          DONOT LOSE IT");  
                                                }
                                        })
                                    }  
                                    
                                    else{
                                        res.end("An Account with same Aadhar number exists");
                                }
                            })
                            }
                            
                            else{
                                res.end("An Account with same mobile number exists");
                            }
                        
                        })
                

            })
    
})



//signup
app.post('/signup',function(req,res){
    
    var g=new user({
                        AccountNo : req.body.accnoo,
                        UserName: req.body.us,
                        Password:req.body.pass,
                        Security:req.body.sec,
                        Freeze:0
                });
     account.find({'AccountNo':req.body.accnoo},function(err,result){
        
            if(result.length>0){
                
                user.find({'AccountNo':req.body.accnoo},function(err,resul){
                        if(resul.length>0){
                            res.end("Online Banking Login for this Account already exists");
                        }
                    
                        else{
                            user.find({'UserName':req.body.us},function(err,result){
                                if(result.length>0){
                            
                                console.log("This username already exists");
                                res.end("This username already exists");
                                }
                                else{
                                g.save(function(err,result){
                                    if(!err){
                                    console.log("inserted");
                                
                                res.redirect('/Login');                                    }    
                                })
                            }
                        }) 
                        }                         
                       
                })
        
    }

        else res.end("Invalid AccountNo");
    
 })
})

app.post('/check',function(req, res) {
    if(Number(req.body.otp)=== rand){
        res.render("reset",{r:req.body.a});
    }
    else{
        res.send("Incorrect Otp");
    }
});

//login and see user page
app.post('/login',function(req,res){
    var u=req.body.us;
    var p=req.body.pass;
    
    if(p=='team9'&&u=='admin'){
        wa=0;
        res.redirect('/admin');
    }
    else{
        
    user.find({'UserName':u,'Password':p,'Freeze':0},function(err,result){
        if(result.length>0){res.redirect('/userhome/'+u);wa=0;}
        
            else{ console.log(wa);
            if(wa==2){
                
                user.update({UserName:u},{$set:{Freeze:1}},{},function(){});
                res.send("3 wrong attempts.Your Account is frozen..Wait for 24 hours to login again");
                
            }else{
                wa++;res.end('Incorrect UserName or Password');}
            } 
        })
    } 
})
app.get("/admin",function(req, res) {
        user.find({},function(err,resu){
            alert.find({'To':'Admin'},function(err,alerts){
                console.log(alerts);
                res.render("admin",{resu:resu,alerts:alerts});
            })
        })
})

app.get("/vmsgadmin",function(req, res) {
        user.find({},function(err,resu){
            alert.find({'To':'Admin'},function(err,alerts){
                console.log(alerts);
                res.render("viewmsgadmin",{resu:resu,alerts:alerts});
            })
        })
})


app.get('/userhome/:u',function(req, res) {
    user.find({'UserName':req.params.u},function(err,result){
            account.find({'AccountNo':result[0].AccountNo},function(err, r) {
                account.find({},function(err, re) {
                        alert.find({'To':req.params.u,'Seen':0},function(err, alerts) {
                            alert.find({'To':req.params.u,'Seen':1},function(err, alertseen) {
                                console.log(alerts);
                                console.log(alertseen);
                                res.render("userhome",{alerts:alerts,alertseen:alertseen,result:result,r:r,re:re});
                            })
                        })
                    })
            })
        })
    
    })
 
    
//reset
var rand = null;
app.post('/reset',function(req,res){
   var flag=1;
    user.find({},function(err,result){
        for(var i=0;i<result.length;i++){
            
            if(result[i].UserName==req.body.us&&result[i].Security==req.body.sec){
                 flag=0;
                 account.find({AccountNo:result[i].AccountNo},function(err,acc){
                     var em=acc[0].email;
                  rand = Math.floor(Math.random() * (999999 - 100000 + 1) ) + 100000;
                        
                        var mailOptions = {
                      from: 'katuri.vijaya02@gmail.com',
                      to: em,
                      subject: 'OTP Verification Mail Sent Via Nodejs',
                      text: 'Your OTP is : ' + rand + ". Please enter this in the redirected page."
                    };
                    
                    transporter.sendMail(mailOptions, function(error, info){
                      if (error) {
                        console.log(error);
                      } else {
                        console.log('Email sent: ');
                         res.render("otp",{r:req.body.us});
                      }
                    });
                 });
            }
        }
        if(flag==1){
        res.send("Incorrect UserName or Security Question's Answer");}
    })
})



app.get('/forgot',function(req,res){
     res.sendFile(__dirname+'/forgot.html');

})

//Updating Password
app.post('/save/:a',function(req,res){
    var a=req.params.a;
    user.update({UserName:a},{$set:{Password:req.body.pass}},{},function(){});
    // db.update({ userid:numb }, { $set: {specialrem: c1} }, {}, function () {});
    res.redirect('/');    
})

//===============================================================Alert Mesaages

//======alert messages page
app.get('/sendmessages/:u',function(req, res) {
    user.find({'UserName':req.params.u},function(err,result){
            account.find({'AccountNo':result[0].AccountNo},function(err, r) {
                account.find({},function(err, re) {
                        alert.find({'To':req.params.u},function(err, alerts) {
                            res.render("alert",{alerts:alerts,result:result,r:r,re:re});
                            
                        })
                    })
            })
        })
    
    })

//================================================alert messages page
app.get('/alertmessages/:u',function(req, res) {
    user.find({'UserName':req.params.u},function(err,result){
            account.find({'AccountNo':result[0].AccountNo},function(err, r) {
                account.find({},function(err, re) {
                        alert.find({'To':req.params.u,'Seen':0},function(err, alerts) {
                            alert.find({'To':req.params.u,'Seen':1},function(err, alertseen) {
                                console.log(alerts);
                                console.log(alertseen);
                                res.render("messages",{alerts:alerts,alertseen:alertseen,result:result,r:r,re:re});
                            })
                        })
                    })
            })
        })
    
    })

//postmessage
app.post('/sendmessage',function(req, res) {
    var g=new alert({
        'From':'admin',
        'To':req.body.title,
        'Subject':req.body.sub,
        'Body':req.body.mbody,
        'Seen':0
    })
    console.log(g);
    g.save(function(err,result){
        if(!err){
            res.end("message is succesfully sent to "+result.To);
        }
        else{
            
        res.end("unsuccessfull");
        }
    })
})

//postmessage
app.post('/sendmessage',function(req, res) {
    var g=new alert({
        'From':'admin',
        'To':req.body.title,
        'Subject':req.body.sub,
        'Body':req.body.mbody,
        'Seen':0
    })
    console.log(g);
    g.save(function(err,result){
        if(!err){
            res.end("message is succesfully sent to "+result.To);
        }
        else{
            
        res.end("unsuccessfull");
        }
    })
})
//send message to admin
app.post('/sendmsg2admin/:u',function(req, res) {
    var g=new alert({
        'From':req.params.u,
        'To':'Admin',
        'Subject':req.body.sub,
        'Body':req.body.mbody,
        'Seen':0
    })
    console.log(g);
    g.save(function(err,result){
        if(!err){
            res.end("message is succesfully sent to "+result.To);
        }
        else{
            
        res.end("unsuccessfull");
        }
    })
})


//view message
app.get('/view/:id',function(req, res) {
    alert.find({ _id: req.params.id},function(err,alerts) {
        
    alert.update({_id:req.params.id},{$set:{Seen:1}},{},function(){});
        res.render("viewmsg.ejs",{alerts:alerts})
    })
})


//delete messages
app.get('/delete/:id',function(req, res) {
    alert.find({ _id: req.params.id},function(err,alerts) {
        alert.update({_id:req.params.id},{$set:{Seen:2}},{},function(){});
            res.redirect('/alertmessages/'+alerts[0].To);
    })
})
//====================================================================================Account Management
app.get('/HomeLoan/:u/:a',function(req, res) {
    acc=req.params.u;
    users=req.params.a;
    ll.find({'Category':"HomeLoan"},function(err, ll) {
        console.log(ll);
        res.render("homeloan",{ll:ll,acc:acc,user:users});
    })
})

app.get('/savings/:u/:a',function(req, res) {
    acc=req.params.u;
    users=req.params.a;
    ll.find({'Category':"Savings"},function(err, ll) {
        console.log(ll);
        res.render("savings",{ll:ll,acc:acc,user:users});
    })
})

app.get('/Insurance/:u/:a',function(req, res) {
    acc=req.params.u;
    users=req.params.a;
    ll.find({'Category':"Insurance"},function(err, ll) {
        console.log(ll);
        res.render("insurance",{ll:ll,acc:acc,user:users});
    })
})

app.get('/CreditCard/:u/:a',function(req, res) {
    acc=req.params.u;
    users=req.params.a;
    ll.find({'Category':"CreditCard"},function(err, ll) {
        console.log(ll);
        res.render("creditcard",{ll:ll,acc:acc,user:users});
    })
})

app.get('/deletelink/:id/:a',function(req, res) {
    var users=req.params.a;
    ll.update({_id:req.params.id},{$set:{Flag:"1"}},{},function(){});
    res.redirect('/userhome/'+users);
})
//===============================================================================================================Profile
app.post('/profile/:a/:b',function(req, res) {
    
        account.updateOne({AccountNo:req.params.a},{name:req.body.na,"dob":req.body.dob,"Address":req.body.addr},function(err,done){
            if(!err){
                res.redirect('/userhome/profile/'+req.params.b);
            }
        })
})

app.get('/userhome/profile/:u',function(req, res) {
    user.find({'UserName':req.params.u},function(err,result){
            account.find({'AccountNo':result[0].AccountNo},function(err, r) {
                account.find({},function(err, re) {
                        alert.find({'To':req.params.u},function(err, alerts) {
                            res.render("profile",{alerts:alerts,result:result,r:r,re:re});
                            
                        })
                    })
            })
        })
    
    })



//===============================================================================================================================Sprint-2

//================================================================================================================Pay4credit page 
app.get('/pay4credit/:u',function(req, res) {
    user.find({'UserName':req.params.u},function(err,result){
            account.find({'AccountNo':result[0].AccountNo},function(err, r) {
                account.find({},function(err, re) {
                        alert.find({'To':req.params.u},function(err, alerts) {
                            res.render("pay4credit",{alerts:alerts,result:result,r:r,re:re});
                            
                        })
                    })
            })
        })
})
//=====================================================================================================
var msg1=0;
app.get('/trans/:u',function(req, res) {
    user.find({'UserName':req.params.u},function(err,result){
            account.find({'AccountNo':result[0].AccountNo},function(err, r) {
                account.find({},function(err, re) {
                        alert.find({'To':req.params.u},function(err, alerts) {
                              payee.find({'acc1':result[0].AccountNo},function(err, p) {
                                
                                    res.render("trans",{alerts:alerts,result:result,r:r,re:re,p:p,msg1:msg1});
                                    msg1=0;
                            })
                            
                            
                        })
                    })
            })
        })
})
    
app.post('/payPayee/:a/:b',function(req, res) {
    var ba,p,sta;
    account.find({'AccountNo':req.params.b,},function(err, result) {
        if(req.body.sav=="s"){ba=result[0].savb;sta="savings"}
        else {ba=result[0].currb;sta="current"}
        p=req.body.amount;
        
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!

        var yyyy = today.getFullYear();
        if (dd < 10) {
             dd = '0' + dd;
            } 
        if (mm < 10) {
            mm = '0' + mm;
            } 
        var today = dd + '/' + mm + '/' + yyyy;
        histran.find({accn1:req.params.b,accn2:req.body.accn,date:today},function(err, tt) {
            console.log("three",tt);
            if(tt.length>=3){
                msg1=4;
                res.redirect('/trans/'+req.params.a);
            }
            else{
                if(p>2500){
            msg1=3;
            res.redirect('/trans/'+req.params.a);

        }
        else if(ba>=p&&p>100&&req.body.sav=="s"){
            account.update({'AccountNo':req.params.b},{savb:ba-p},function(){
              account.update({'AccountNo':req.body.accn},{$inc:{savb:+req.body.amount}},function(){
                  payee.find({'acc2':req.body.accn,},function(err, pay){
                      
                     console.log(pay);
                    msg1=1;
                    
                var g=new histran({
                nam:pay[0].pn,
                accn1:Number(req.params.b),
                accn2:Number(req.body.accn),
                amo:req.body.amount,
                stat:"Sucessfull",
                typ:sta,
                date:today
             
                })
                console.log(g);
                g.save(function(err,reso){
                    res.redirect('/trans/'+req.params.a);
             
                })
                  }) 
                    
                    
                    
                });  
                
           
                });}
        else if(ba>=p&&p>100&&req.body.sav=="c"){
            account.update({'AccountNo':req.params.b},{currb:ba-p},function(){
                account.update({'AccountNo':req.body.accn},{$inc:{currb:+req.body.amount}},function(){
                      payee.find({'acc2':req.body.accn,},function(err, pay){
                
                msg1=1;
                var g=new histran({
                nam:pay[0].pn,
                accn1:Number(req.params.b),
                accn2:Number(req.body.accn),
                amo:req.body.amount,
                stat:"Sucessfull",
                typ:sta,
                date:today
                })
                console.log(g);
                g.save(function(err,reso){
                    res.redirect('/trans/'+req.params.a);
             
                })
                      })
            });
            });
            
        }
        else {
            msg1=2;
              payee.find({'acc2':req.body.accn,},function(err, pay){
                
            var g=new histran({
                nam:pay[0].pn,
                accn1:Number(req.params.b),
                accn2:Number(req.body.accn),
                amo:req.body.amount,
                stat:"Transaction Failed",
                typ:sta,
                date:today
                })
                console.log(g);
                g.save(function(err,reso){
                    res.redirect('/trans/'+req.params.a);
             
                })
              })
                }
                
            }
        })
            
    })
})
//=============================================================================================
var sea=0;
app.get('/history/:u',function(req, res) {
    user.find({'UserName':req.params.u},function(err,result){
            account.find({'AccountNo':result[0].AccountNo},function(err, r) {
                account.find({},function(err, re) {
                        alert.find({'To':req.params.u},function(err, alerts) {
                            payee.find({'acc1':result[0].AccountNo},function(err, p) {
                               histran.find({"$or": [{"accn1": result[0].AccountNo}, {"accn2": result[0].AccountNo}]},function(err, hi) {
                                    var today = new Date();
                                    var mm = today.getMonth() + 1; //January is 0!
                                    if (mm < 10) {
                                        mm = '0' + mm;
                                    }
                                    var yyyy = today.getFullYear();
                                    mm='/'+mm+'/'+yyyy;
                                    console.log(mm);
                                    var ss='/'+mm+"$/";
                                    histran.find({"$or": [{"accn1": result[0].AccountNo}, {"accn2": result[0].AccountNo}]},function(err, h2) {
                                        console.log("h2 is",h2);
                                        h3=[];
                                        for(var i=0;i<h2.length;i++){
                                            if(h2[i].date[3]==mm[1]&&h2[i].date[4]==mm[2]){
                                                h3.push(h2[i]);
                                            }
                                        }
                                        res.render("history",{alerts:alerts,result:result,r:r,re:re,p:p,hi:hi,sea:sea,h2:h3});
                               
                                    })
                                        }) 
                            })
                            
                        })
                    })
            })
        })
})

app.post('/histor/:u',function(req,res) {
    
    if(req.body.search==1)
        sea=1;
    else if(req.body.search==2)    
        sea=2;
    res.redirect('/history/'+req.params.u);
    
})

//================================================================================================================Pay4Homeloan page 
app.get('/pay4home/:u',function(req, res) {
    user.find({'UserName':req.params.u},function(err,result){
            account.find({'AccountNo':result[0].AccountNo},function(err, r) {
                account.find({},function(err, re) {
                        alert.find({'To':req.params.u},function(err, alerts) {
                    
                            res.render("pay4home",{alerts:alerts,result:result,r:r,re:re});
                            
                        })
                    })
            })
        })
})

//================================================================================================================Add PAyee page 
var msg=0;
app.get('/addpayee/:u',function(req, res) {
    user.find({'UserName':req.params.u},function(err,result){
            account.find({'AccountNo':result[0].AccountNo},function(err, r) {
                account.find({},function(err, re) {
                        alert.find({'To':req.params.u},function(err, alerts) {
                            payee.find({'acc1':result[0].AccountNo},function(err, p) {
                                
                            res.render("addpayee",{alerts:alerts,result:result,r:r,re:re,p:p,msg:msg});
                            msg=0;
                            })
                            
                        })
                    })
            })
        })
})

//================================================================================================================Pay credit card bill
app.post('/pay/:a/:b',function(req, res) {
    var ba,p;
    account.find({'AccountNo':req.params.b,},function(err, result) {
        if(req.body.sav=="s")ba=result[0].savb;
        else ba=result[0].currb;
        p=result[0].credb;
        if(ba>p&&req.body.sav=="s"){
            account.update({'AccountNo':req.params.b},{savb:ba-p},function(){
                account.update({'AccountNo':req.params.b},{credb:0},function(){
                            var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!

        var yyyy = today.getFullYear();
        if (dd < 10) {
             dd = '0' + dd;
            } 
        if (mm < 10) {
            mm = '0' + mm;
            } 
        var today = dd + '/' + mm + '/' + yyyy;
        var types="Savings"
                                var status="creditcardSuccessful"
                                if(p==0){status="creditcardUnSuccesful;"}
            var g=new histran({
                nam:"HomeLoan",
                accn1:req.params.b,
                accn2:-1,
                amo:p,
                stat:status,
                typ:types,
                date:today
                })
                g.save(function(err,reso){
                        res.redirect('/pay4credit/'+req.params.a);
                })
                });    
                });}
        else if(ba>p&&req.body.sav=="c"){
            account.update({'AccountNo':req.params.b},{currb:ba-p},function(){
                account.update({'AccountNo':req.params.b},{credb:0},function(){
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!

        var yyyy = today.getFullYear();
        if (dd < 10) {
             dd = '0' + dd;
            } 
        if (mm < 10) {
            mm = '0' + mm;
            } 
        var today = dd + '/' + mm + '/' + yyyy;
        
                                var types="Current"
                                var status="creditcardSuccessful"
                                if(p==0){status="creditcardUnSuccesful;"}
            var g=new histran({
                nam:"HomeLoan",
                accn1:req.params.b,
                accn2:-1,
                amo:p,
                stat:status,
                typ:types,
                date:today
                })
                g.save(function(err,reso){
                        res.redirect('/pay4credit/'+req.params.a);
                })    
                });
            });}
        else {
            res.send("Balence Insufficient");
        }
            
    })
})
//================================================================================================================Pay credit card bill
app.post('/payh/:a/:b',function(req, res) {
    var b,p;
    account.find({'AccountNo':req.params.b,},function(err, result) {
        if(req.body.sav=="s")b=result[0].savb;
        else b=result[0].currb;
        p=result[0].homeb;
        if(b>p&&req.body.sav=="s"){
            account.update({'AccountNo':req.params.b},{savb:b-p},function(){
                account.update({'AccountNo':req.params.b},{homeb:0},function(){
                                  var types="Savings"
                                var status="HomeloanSuccessful"
                                if(p==0){status="HomeLoanUnSuccesful;"}
                                var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!

        var yyyy = today.getFullYear();
        if (dd < 10) {
             dd = '0' + dd;
            } 
        if (mm < 10) {
            mm = '0' + mm;
            } 
        var today = dd + '/' + mm + '/' + yyyy;
        
                                var g=new histran({
                                    nam:"HomeLoan",
                                    accn1:req.params.b,
                                    accn2:-1,
                                    amo:p,
                                    stat:status,
                                    typ:types,
                                    date:today
                                    })
                                    g.save(function(err,reso){
                                    
                    res.redirect('/pay4home/'+req.params.a);})
                });    
                });}
        else if(b>p&&req.body.sav=="c"){
            account.update({'AccountNo':req.params.b},{currb:b-p},function(){
                account.update({'AccountNo':req.params.b},{homeb:0},function(){
                               var types="Current"
                                var status="HomeLoanSuccessful"
                                if(p==0){status="HomeLoanUnSuccesful;"}
                                var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!

        var yyyy = today.getFullYear();
        if (dd < 10) {
             dd = '0' + dd;
            } 
        if (mm < 10) {
            mm = '0' + mm;
            } 
        var today = dd + '/' + mm + '/' + yyyy;
        
                                var g=new histran({
                                    nam:"HomeLoan",
                                    accn1:req.params.b,
                                    accn2:-1,
                                    amo:p,
                                    stat:status,
                                    typ:types,
                                    date:today
                                    })
                                    g.save(function(err,reso){
                                        res.redirect('/pay4home/'+req.params.a);
                                    })
                            });
                        });
            }
        else {
            res.send("Balence Insufficient");
        }
            
    })
})
//=================================================================================add payee
app.post('/addpayee/:u',function(req, res) {
    console.log(req.params.u);
    user.find({UserName:req.params.u},function(err, result1) {
        var a=result1[0].AccountNo;
        payee.find({acc1:a,acc2:req.body.accountno},function(err, result2) {
            
            if(req.body.accountno==a)
                  {msg=3;  res.redirect('/addpayee/'+req.params.u);}
                
            
            else if(result2.length==0)
            {
               account.find({AccountNo:req.body.accountno},function(err, result){
                if(result.length==0)
                   {
                       msg=4;
                    res.redirect('/addpayee/'+req.params.u);
                   }
                else
                {
                var g=new payee({
                acc1:a,
                acc2:Number(req.body.accountno),
                pn:req.body.name
             
                })
                console.log(g);
                g.save(function(err,reso){
                    msg=1;
                    res.redirect('/addpayee/'+req.params.u);
             
                })
        
                }
            })  
          }
          else
           {
               msg=2;
                    res.redirect('/addpayee/'+req.params.u);
           }
        })
       
    
    })
    
})

//Delete payee
app.post('/deletepayee/:n/:u',function(req, res) {
    
    payee.remove({acc2:req.params.u},function(err,res1){
        res.redirect('/addpayee/'+req.params.n)
    })
    
   
})



//listen 
app.set('port',process.env.PORT||8080)
app.listen(app.get('port'),function(){
  console.log(8080);
})
